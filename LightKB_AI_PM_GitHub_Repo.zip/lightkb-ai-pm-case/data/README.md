# Data

> 所有数据均为**合成样本**，用于复现报告中的指标逻辑，不含真实客户数据。

## 文件

### `pilot_summary.csv`

3 家 Pilot 客户的 4 周汇总：

| 列 | 含义 |
|---|---|
| `customer` | 匿名客户名 |
| `seats` | 坐席数 |
| `docs` | 文档数 |
| `sessions` | 会话数 |
| `ai_answers` | AI 回答数 |
| `adopted` | 被坐席采纳数 |
| `transfers` | 转人工数 |
| `csat` | 客户满意度（1—5） |
| `hit_at_1` | 检索第一名包含金标答案的比例 |
| `citation_accuracy` | 引用能支撑结论的比例 |
| `hallucination_rate` | 无引用支撑断言的比例 |

复算：

```bash
python analysis/evaluate.py
```

### `golden_set_template.csv`

20 题 starter template，覆盖 4 类意图、3 个难度、30% 不可回答/需澄清：

- `answerable`：`yes` / `no` / `needs_clarification`
- `gold_answer`：金标答案
- `gold_citation`：金标引用位置

> 报告中的评测使用 120 题版本；这里提供 20 题模板，方便复用到下一个项目。建议按 4 类意图 × 3 个难度 × 10 题扩到 120 题，并保持 30% 不可回答。

## 使用建议

1. 不要用真实客户数据直接提交到公开仓库；
2. 如果要用真实数据，先做脱敏、去标识化、权限审查；
3. 评测集要版本化，每次改动记录原因；
4. 新增 Bad Case 必须进入回归集，否则下个版本还会错。
