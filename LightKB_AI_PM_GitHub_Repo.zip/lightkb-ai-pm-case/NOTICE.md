# NOTICE

## 1. Course project simulation

This repository is a **course capstone simulation** for the “腾讯未来产品经理创造营” (Tencent Future Product Manager Creation Camp). It is **not** a real Tencent project, commercial plan, investment offering, or hiring evaluation.

The two course certificates referenced in the report are:

- 必修课-方法论入门 — `TCAMP20260212001496`
- 必修课-进阶实战 — `TCAMP20260212007746`

They indicate completion of course learning only. They do not imply employment, endorsement, or affiliation with Tencent.

## 2. Simulated data

Customer interviews, pilot metrics, pricing, costs, and financial projections are **simulated reconstructions** created to demonstrate product-management method. They are not audited operating data. The assumptions are documented in:

- `docs/LightKB_Project_Report.pdf` (sections 01, 06, 08)
- `docs/LightKB_Unit_Economics.xlsx`
- `analysis/unit_economics.py`
- `data/pilot_summary.csv`

Do not cite these numbers as real market data or real company performance.

## 3. Real project material

The technical approach and evaluation method are inspired by the author’s real projects, including the enterprise hybrid-retrieval knowledge base. Links to the real repositories are listed in Appendix G of the report and on GitHub: <https://github.com/Samuel34671009>.

## 4. Trademarks

Tencent, 腾讯招聘, 腾讯学堂, and related names and marks are trademarks of Tencent Holdings Limited and/or its affiliates. All other trademarks are the property of their respective owners. This repository is not affiliated with, endorsed by, or sponsored by Tencent.

## 5. Privacy

The report includes the author’s name and certificate numbers for provenance. If you fork or republish this repository, consider whether you want to keep that information public. The original certificate images and QR codes are **not** included in this repository.

No real customer data is included. The `data/` files are synthetic samples.

## 6. No warranty

The materials are provided “as is”, without warranty of any kind. Product, pricing, legal, and compliance decisions require independent validation with real customers, legal counsel, and security review.
