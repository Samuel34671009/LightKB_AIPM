# Research

| 文件 | 内容 |
|---|---|
| [interview_guide.md](interview_guide.md) | 12 人访谈设计、10 个问题、追问技巧、分析方法 |
| [personas.md](personas.md) | ICP、3 个人物、JTBD、非目标用户 |
| [competitive_landscape.md](competitive_landscape.md) | TAM/SAM/SOM、四类竞品、竞争空位、壁垒 |

> 所有访谈、人物原话、市场数字均为课程项目模拟，按真实客服场景合理化编写，不是真实客户数据。
