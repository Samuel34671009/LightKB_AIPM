// LightKB prototype interaction layer.
// No backend, no external dependencies.

const chat = document.getElementById("chat");
const composer = document.getElementById("composer");
const queryInput = document.getElementById("query");
const citationsPanel = document.getElementById("citations");
const miniMetrics = document.getElementById("miniMetrics");
const clearBtn = document.getElementById("clearBtn");
const toast = document.getElementById("toast");

const initialChatHtml = chat.innerHTML;
let toastTimer = null;

const CONFIDENCE_LABEL = {
  high: "高置信度",
  medium: "中置信度",
  low: "低置信度"
};

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function normalize(value) {
  return String(value)
    .toLowerCase()
    .replace(/[\s，。！？、；：""''（）()【】\[\]·.,!?;:]/g, "");
}

function scoreQa(question, qa) {
  const q = normalize(question);
  let score = 0;
  for (const keyword of qa.keywords) {
    const k = normalize(keyword);
    if (k && q.includes(k)) {
      score += k.length >= 4 ? 3 : 2;
    }
  }
  if (q === normalize(qa.question)) {
    score += 20;
  }
  // a small bonus for overlapping intent words
  if (q.includes("退") && qa.intent.includes("政策")) score += 1;
  if (q.includes("失败") && qa.intent.includes("故障")) score += 1;
  return score;
}

function findAnswer(question) {
  let best = null;
  for (const qa of QA) {
    const score = scoreQa(question, qa);
    if (!best || score > best.score) {
      best = { qa, score };
    }
  }
  if (best && best.score >= 4) {
    return { type: "answer", qa: best.qa, score: best.score };
  }
  return { type: "fallback", qa: null, score: best ? best.score : 0 };
}

function scrollToBottom() {
  chat.scrollTop = chat.scrollHeight;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("show"), 2200);
}

function addUserMessage(text) {
  const article = document.createElement("article");
  article.className = "msg user";
  article.innerHTML = `
    <div class="avatar">你</div>
    <div class="bubble"><p>${escapeHtml(text)}</p></div>
  `;
  chat.appendChild(article);
  scrollToBottom();
}

function addLoadingMessage() {
  const article = document.createElement("article");
  article.className = "msg ai";
  article.dataset.loading = "true";
  article.innerHTML = `
    <div class="avatar">AI</div>
    <div class="bubble"><p class="bubble-title">正在检索…</p><p class="tiny">混合检索 → Rerank → 引用校验</p></div>
  `;
  chat.appendChild(article);
  scrollToBottom();
  return article;
}

function renderMiniMetrics() {
  miniMetrics.innerHTML = METRICS.map((m) => `
    <div class="mini-metric">
      <div>
        <strong>${escapeHtml(m.value)}</strong>
        <div><span>${escapeHtml(m.label)}</span></div>
      </div>
      <span>${escapeHtml(m.note)}</span>
    </div>
  `).join("");
}

function renderCitations(ids) {
  const docs = ids.map((id) => KB.find((doc) => doc.id === id)).filter(Boolean);
  if (docs.length === 0) {
    citationsPanel.classList.add("empty");
    citationsPanel.innerHTML = `
      <div class="empty-state">
        <span class="empty-icon">[ ]</span>
        <strong>没有可引用的原文</strong>
        <p>这就是系统说“没找到”的原因。建议转人工，或补充订单/商品信息。</p>
      </div>
    `;
    return;
  }

  citationsPanel.classList.remove("empty");
  citationsPanel.innerHTML = docs.map((doc, index) => `
    <article class="citation-card" data-cite="${escapeHtml(doc.id)}" tabindex="0" role="button" aria-label="查看引用 ${escapeHtml(doc.title)}">
      <div class="citation-title">
        <span>[${index + 1}] ${escapeHtml(doc.title)}</span>
        <span>${escapeHtml(doc.updated)}</span>
      </div>
      <p class="citation-text">${escapeHtml(doc.text)}</p>
      <div class="citation-meta">${escapeHtml(doc.section)} · 点击定位原文</div>
    </article>
  `).join("");

  citationsPanel.querySelectorAll(".citation-card").forEach((card) => {
    card.addEventListener("click", () => activateCitation(card.dataset.cite));
    card.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        activateCitation(card.dataset.cite);
      }
    });
  });
}

function activateCitation(id) {
  const card = citationsPanel.querySelector(`[data-cite="${id}"]`);
  if (!card) return;
  citationsPanel.querySelectorAll(".citation-card").forEach((el) => el.classList.remove("active"));
  card.classList.add("active");
  const doc = KB.find((d) => d.id === id);
  showToast(`已定位：${doc ? doc.title : "原文"}`);
  card.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function renderAnswer(result, question) {
  const qa = result.qa;
  const isFallback = result.type === "fallback";
  const article = document.createElement("article");
  article.className = "msg ai";

  const confidence = isFallback ? "low" : qa.confidence;
  const label = CONFIDENCE_LABEL[confidence] || "低置信度";
  const text = isFallback ? FALLBACK.message : qa.answer;
  const intent = isFallback ? FALLBACK.intent : qa.intent;
  const citations = isFallback ? [] : qa.citations;

  const citationChips = citations.map((id, index) => {
    const doc = KB.find((d) => d.id === id);
    return `<button class="chip" type="button" data-cite="${escapeHtml(id)}">[${index + 1}] ${escapeHtml(doc ? doc.title : id)}</button>`;
  }).join("");

  const actions = isFallback
    ? `<button class="btn handoff" type="button" data-action="handoff">转人工</button>
       <button class="btn ghost" type="button" data-action="clarify">补充信息</button>`
    : `<button class="btn primary" type="button" data-action="useful">有用</button>
       <button class="btn ghost" type="button" data-action="not-useful">没用</button>
       <button class="btn handoff" type="button" data-action="handoff">转人工</button>`;

  article.innerHTML = `
    <div class="avatar">AI</div>
    <div class="answer-card">
      <div class="answer-head">
        <span class="answer-label">AI 答案</span>
        <span class="confidence ${confidence}">${label}</span>
      </div>
      <p class="answer-text ${isFallback ? "fallback" : ""}">${escapeHtml(text)}</p>
      <div class="answer-meta">
        <span class="chip intent">${escapeHtml(intent)}</span>
        ${citationChips}
      </div>
      <div class="answer-actions">${actions}</div>
      <p class="answer-note">${isFallback
        ? "没有可靠依据，不猜测。转人工或补充信息后再试。"
        : "AI 生成，请核对引用后发送；系统不会自动回复客户。"
      }</p>
    </div>
  `;

  chat.appendChild(article);

  article.querySelectorAll("[data-cite]").forEach((chip) => {
    chip.addEventListener("click", () => activateCitation(chip.dataset.cite));
  });
  article.querySelectorAll("[data-action]").forEach((button) => {
    button.addEventListener("click", () => handleAction(button.dataset.action, question));
  });

  renderCitations(citations);
  scrollToBottom();
}

function handleAction(action, question) {
  if (action === "useful") {
    showToast("已记录：有用。会进入正面样本。");
  } else if (action === "not-useful") {
    showToast("已记录：没用。会进入 Bad Case 队列。");
  } else if (action === "handoff") {
    showToast("已转人工（模拟）。工单会带上当前问题与引用。");
  } else if (action === "clarify") {
    queryInput.focus();
    queryInput.value = question ? `${question}（补充：订单号 / 商品型号）` : "";
    showToast("请补充订单号或商品型号。");
  }
}

function submitQuestion(raw) {
  const question = String(raw || "").trim();
  if (!question) {
    showToast("先输入一个客户问题。");
    queryInput.focus();
    return;
  }

  addUserMessage(question);
  queryInput.value = "";
  const loading = addLoadingMessage();

  window.setTimeout(() => {
    loading.remove();
    const result = findAnswer(question);
    renderAnswer(result, question);
  }, 320);
}

composer.addEventListener("submit", (event) => {
  event.preventDefault();
  submitQuestion(queryInput.value);
});

document.querySelectorAll(".sample").forEach((button) => {
  button.addEventListener("click", () => {
    const q = button.dataset.q || button.textContent;
    queryInput.value = q;
    submitQuestion(q);
  });
});

clearBtn.addEventListener("click", () => {
  chat.innerHTML = initialChatHtml;
  citationsPanel.classList.add("empty");
  citationsPanel.innerHTML = `
    <div class="empty-state">
      <span class="empty-icon">[ ]</span>
      <strong>还没有引用</strong>
      <p>问一个问题，引用会出现在这里。</p>
    </div>
  `;
  queryInput.value = "";
  queryInput.focus();
  showToast("会话已清空。");
});

renderMiniMetrics();
queryInput.focus();
