// LightKB prototype knowledge base and sample Q&A.
// All content is synthetic, for product-demo purposes only.

const KB = [
  {
    id: "size-01",
    title: "尺码表 §2",
    section: "尺码与版型",
    updated: "2026-01",
    text: "170cm / 50kg 建议 M 码。本款为修身版型，肩宽 38cm，胸围 88cm；如偏好宽松，可选 L 码。",
    tags: ["尺码", "170", "50kg", "连衣裙", "m码", "偏小"]
  },
  {
    id: "care-01",
    title: "洗护说明 §3",
    section: "真丝洗护",
    updated: "2026-01",
    text: "真丝建议冷水手洗或干洗，不可机洗、不可漂白，阴凉处悬挂晾干，避免暴晒。",
    tags: ["真丝", "洗", "洗护", "干洗", "连衣裙"]
  },
  {
    id: "spec-01",
    title: "产品规格 §1",
    section: "电源规格",
    updated: "2025-12",
    text: "充电器支持 100—240V 宽电压输入，50/60Hz，适合国内及多数海外地区使用。",
    tags: ["充电器", "220v", "电压", "规格"]
  },
  {
    id: "warranty-01",
    title: "保修政策 §1",
    section: "小家电保修",
    updated: "2026-01",
    text: "整机保修 1 年，电机保修 3 年；需保留购买凭证，人为损坏不在保修范围内。",
    tags: ["保修", "小家电", "电机", "多久"]
  },
  {
    id: "return-01",
    title: "售后政策 §2.1",
    section: "退货时效",
    updated: "2026-01",
    text: "7 天无理由退货；质量问题 15 天内可退，需上传商品问题凭证。",
    tags: ["退货", "7天", "15天", "无理由", "质量问题"]
  },
  {
    id: "return-02",
    title: "售后政策 §2.3",
    section: "退货运费",
    updated: "2026-01",
    text: "质量问题由我方承担退货运费；非质量问题由买家承担，除非商品页明确注明包退。",
    tags: ["运费", "退货", "谁出", "质量问题"]
  },
  {
    id: "member-01",
    title: "会员规则 §4.2",
    section: "优惠叠加",
    updated: "2026-01",
    text: "会员日折扣不与店铺券叠加，可与平台券叠加；最终以结算页显示为准。",
    tags: ["会员日", "折扣", "优惠券", "叠加"]
  },
  {
    id: "logistics-01",
    title: "物流异常 §3",
    section: "签收未收到",
    updated: "2026-01",
    text: "先查驿站/快递柜，联系快递核实；48 小时未解决，转赔付流程。",
    tags: ["签收", "没收到", "物流", "快递", "驿站"]
  },
  {
    id: "payment-01",
    title: "支付FAQ §2",
    section: "支付失败",
    updated: "2025-12",
    text: "依次检查余额、支付限额、网络、银行通道；可更换支付方式或稍后重试。",
    tags: ["支付失败", "付款", "余额", "限额", "网络"]
  },
  {
    id: "missing-01",
    title: "漏发处理 §1",
    section: "少发/漏发",
    updated: "2026-01",
    text: "拍照留存外包装与面单，核对发货清单；48 小时内申请补发或退款。",
    tags: ["少发", "漏发", "少了一件", "补发"]
  },
  {
    id: "invoice-01",
    title: "发票规则 §3",
    section: "发票冲红",
    updated: "2026-01",
    text: "已开发票可以退货，但需先冲红；退款到账时间以财务流程为准。",
    tags: ["发票", "退货", "冲红"]
  },
  {
    id: "crossborder-01",
    title: "跨境售后 §5",
    section: "跨境退货",
    updated: "2026-01",
    text: "跨境订单不支持 7 天无理由；质量问题 7 天内可申请，运费按责任方承担。",
    tags: ["跨境", "退货", "无理由", "质量问题"]
  }
];

const QA = [
  {
    id: "q01",
    question: "这款连衣裙 170cm/50kg 选什么码？",
    answer: "建议 M 码。这款版型偏小，肩宽 38cm，M 码更适合 170/50kg；如果偏好宽松，可以选 L 码。[1]",
    confidence: "high",
    citations: ["size-01"],
    keywords: ["170", "50kg", "连衣裙", "尺码", "选什么码", "m码", "偏小"],
    intent: "事实查询"
  },
  {
    id: "q02",
    question: "退货超过 7 天还能退吗？",
    answer: "7 天无理由退货；如果是质量问题，15 天内仍可退，需要上传商品问题凭证。[1]",
    confidence: "high",
    citations: ["return-01"],
    keywords: ["退货", "7天", "超过", "15天", "无理由", "质量问题"],
    intent: "政策规则"
  },
  {
    id: "q03",
    question: "订单显示签收但我没收到怎么办？",
    answer: "先查驿站/快递柜，再联系快递核实；48 小时未解决，转赔付流程。[1]",
    confidence: "medium",
    citations: ["logistics-01"],
    keywords: ["签收", "没收到", "物流", "快递", "驿站"],
    intent: "故障排查"
  },
  {
    id: "q04",
    question: "会员日折扣能和优惠券叠加吗？",
    answer: "会员日折扣不与店铺券叠加，可与平台券叠加；最终以结算页为准。[1]",
    confidence: "medium",
    citations: ["member-01"],
    keywords: ["会员日", "折扣", "优惠券", "叠加", "平台券"],
    intent: "政策规则"
  },
  {
    id: "q05",
    question: "支付失败是什么原因？",
    answer: "依次检查余额、支付限额、网络、银行通道；可以更换支付方式或稍后重试。[1]",
    confidence: "medium",
    citations: ["payment-01"],
    keywords: ["支付失败", "支付", "失败", "付款", "余额", "限额", "网络", "银行为什么"],
    intent: "故障排查"
  },
  {
    id: "q06",
    question: "收到货发现少了一件怎么办？",
    answer: "拍照留存外包装与面单，核对发货清单；48 小时内申请补发或退款。[1]",
    confidence: "high",
    citations: ["missing-01"],
    keywords: ["少发", "漏发", "少了一件", "补发", "发货清单"],
    intent: "故障排查"
  },
  {
    id: "q07",
    question: "发票已经开了还能退货吗？",
    answer: "可以退货，但需要先冲红发票；退款到账时间以财务流程为准。[1]",
    confidence: "medium",
    citations: ["invoice-01"],
    keywords: ["发票", "退货", "冲红", "已经开了"],
    intent: "政策规则"
  },
  {
    id: "q08",
    question: "跨境订单可以无理由退货吗？",
    answer: "跨境订单不支持 7 天无理由；质量问题 7 天内可申请，运费按责任方承担。[1]",
    confidence: "medium",
    citations: ["crossborder-01"],
    keywords: ["跨境", "退货", "无理由", "海外", "质量问题"],
    intent: "政策规则"
  },
  {
    id: "q09",
    question: "小家电保修多久？",
    answer: "整机保修 1 年，电机保修 3 年；需要保留购买凭证。[1]",
    confidence: "high",
    citations: ["warranty-01"],
    keywords: ["保修", "小家电", "电机", "多久", "几年"],
    intent: "事实查询"
  },
  {
    id: "q10",
    question: "真丝连衣裙怎么洗？",
    answer: "建议冷水手洗或干洗，不可机洗、不可漂白，阴凉处悬挂晾干。[1]",
    confidence: "high",
    citations: ["care-01"],
    keywords: ["真丝", "洗", "洗护", "干洗", "手洗"],
    intent: "事实查询"
  },
  {
    id: "q11",
    question: "这个充电器支持 220V 吗？",
    answer: "支持 100—240V 宽电压输入，国内 220V 可以正常使用。[1]",
    confidence: "high",
    citations: ["spec-01"],
    keywords: ["充电器", "220v", "电压", "支持"],
    intent: "事实查询"
  },
  {
    id: "q12",
    question: "退货的运费谁出？",
    answer: "质量问题由我方承担退货运费；非质量问题由买家承担，除非商品页注明包退。[1]",
    confidence: "high",
    citations: ["return-02"],
    keywords: ["运费", "退货", "谁出", "质量问题", "包退"],
    intent: "政策规则"
  }
];

const FALLBACK = {
  answer: null,
  confidence: "low",
  citations: [],
  intent: "无可靠依据",
  message: "没有找到可靠依据。建议转人工，或补充订单号/商品型号后再试。"
};

const METRICS = [
  { value: "78.4%", label: "Hit@1", note: "120 题 Golden Set" },
  { value: "96.1%", label: "引用准确率", note: "引用能支撑结论" },
  { value: "1.4%", label: "幻觉率", note: "无依据断言 / 全部回答" }
];
