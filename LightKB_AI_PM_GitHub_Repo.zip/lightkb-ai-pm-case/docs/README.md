# Docs

| 文件 | 说明 | 适合 |
|---|---|---|
| [LightKB_Project_Report.pdf](LightKB_Project_Report.pdf) | 35 页主报告：发现、定义、策略、方案、评测、交付、商业、答辩、附录 | 阅读 / 投递 |
| [LightKB_Project_Report.docx](LightKB_Project_Report.docx) | 主报告可编辑版 | 修改 / 二次使用 |
| [LightKB_Defense_Deck.pdf](LightKB_Defense_Deck.pdf) | 12 页答辩 Deck | 放映 |
| [LightKB_Defense_Deck.pptx](LightKB_Defense_Deck.pptx) | 答辩 Deck 可编辑版 | 修改 |
| [LightKB_Unit_Economics.xlsx](LightKB_Unit_Economics.xlsx) | 7 个 sheet：机会评估、指标/OKR、评测、单位经济、12 周计划、风险 | 测算 / 评审 |

## 推荐阅读顺序

1. 先看 [README](../README.md) 和本页；
2. 8 分钟：看 Deck 第 2—9 页；
3. 30 分钟：看报告 00—06；
4. 面试追问：看报告 09.2 的 15 个 Q&A；
5. 想复算：跑 `python analysis/unit_economics.py` 和 `python analysis/evaluate.py`。

> 报告中的客户访谈、Pilot 数据、定价与财务测算为课程项目模拟，详见 [NOTICE](../NOTICE.md)。
