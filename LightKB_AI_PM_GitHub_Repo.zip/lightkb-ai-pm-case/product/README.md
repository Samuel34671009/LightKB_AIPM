# Product Docs

| 文件 | 内容 | 适合谁 |
|---|---|---|
| [PRD.md](PRD.md) | 背景、目标、用户、6 个用户故事、范围、NFR、停止标准 | 产品/研发/设计 |
| [metrics.md](metrics.md) | 北极星、指标树、护栏、埋点最小集 | 产品/数据 |
| [experiment.md](experiment.md) | 离线评测、线上 A/B、分层结果、偏差 | 算法/评测 |
| [pricing.md](pricing.md) | 套餐、成本、单位经济、ROI、敏感性 | 商业/财务 |
| [roadmap.md](roadmap.md) | 12 周计划、12 个月路线、阶段目标、风险 | 全员 |

> 这些文档是 35 页主报告的“可编辑版”。完整叙事、图表与答辩 Q&A 见 [主报告](../docs/LightKB_Project_Report.pdf)。
