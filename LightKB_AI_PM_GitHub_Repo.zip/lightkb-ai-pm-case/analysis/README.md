# Analysis

两个标准库脚本，复算报告里的关键数字。

## `unit_economics.py`

```bash
python analysis/unit_economics.py
```

输出：

- 单次成本拆分；
- 单次收入、毛利、毛利率；
- CAC、回本、LTV、LTV/CAC；
- 客户 ROI 的保守/基准/积极三种情景。

假设都在脚本顶部，改完直接重跑。

## `evaluate.py`

```bash
python analysis/evaluate.py
```

读取 `data/pilot_summary.csv`，输出：

- 3 家客户的明细；
- 加权 Hit@1、引用准确率、幻觉率、CSAT；
- 会话/坐席/AI 回答/采纳的核对值。

脚本带轻量断言；如果数据漂移，CI 会失败。

## 输出

运行后写入 `analysis/output/`：

- `unit_economics.md`
- `pilot_metrics.md`

`analysis/output/*` 默认被 `.gitignore` 忽略，只保留 `.gitkeep`。

## 说明

这些脚本只验证“数字之间是否自洽”，不验证假设是否真实。真实项目需要把假设替换为客户数据、财务数据和实际评测结果。
