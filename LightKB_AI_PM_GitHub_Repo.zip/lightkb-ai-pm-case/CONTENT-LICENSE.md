# Content License

The **written and visual content** in this repository — including the project report, defense deck, product documents, research notes, and README narrative — is licensed under the **Creative Commons Attribution-NonCommercial 4.0 International License (CC BY-NC 4.0)**.

You are free to:

- **Share** — copy and redistribute the material in any medium or format;
- **Adapt** — remix, transform, and build upon the material;

under the following terms:

- **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
- **NonCommercial** — You may not use the material for commercial purposes.
- **No additional restrictions** — You may not apply legal terms or technological measures that legally restrict others from doing the same.

Full license text: <https://creativecommons.org/licenses/by-nc/4.0/legalcode>

## What this does not cover

- Code in `analysis/`, `prototype/`, and `.github/` is licensed under the repository's [MIT License](LICENSE).
- Third-party names and marks (including Tencent, 腾讯招聘, 腾讯学堂) remain the property of their respective owners.
- Simulated data and financial assumptions are for demonstration only; they are not investment, legal, or business advice.

## Attribution example

> LightKB · 轻量企业知识库 — AI Product Manager case study by Wang Bingsen, licensed under CC BY-NC 4.0. Source: https://github.com/Samuel34671009/lightkb-ai-pm-case
